import { Routes, RouterModule } from "@angular/router";
// import { LaunchPadComponent } from "./launch-pad.component";
//import { DashboardComponent } from "./components/dashboard/dashboard.component";

const routes: Routes = [
  // {
  //   path: "",
  //   component: DashboardComponent
  //   // children: [{ path: "launcher", component: DashboardComponent }]
  // }
];

export const LaunchPadRoutes = RouterModule.forChild(routes);
