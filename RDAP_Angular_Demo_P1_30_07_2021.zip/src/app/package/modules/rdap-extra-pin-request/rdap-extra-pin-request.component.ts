import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rdap-extra-pin-request',
  templateUrl: './rdap-extra-pin-request.component.html',
  styleUrls: ['./rdap-extra-pin-request.component.scss']
})
export class RDAPExtraPINRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
