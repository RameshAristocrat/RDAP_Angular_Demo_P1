import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rdap-search-shared',
  templateUrl: './rdap-search-shared.component.html',
  styleUrls: ['./rdap-search-shared.component.scss']
})
export class RdapSearchSharedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
