import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rdap-config-studio',
  templateUrl: './rdap-config-studio.component.html',
  styleUrls: ['./rdap-config-studio.component.scss']
})
export class RdapConfigStudioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
