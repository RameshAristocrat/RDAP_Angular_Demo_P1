import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setup-table-home',
  templateUrl: './setup-table-home.component.html',
  styleUrls: ['./setup-table-home.component.scss']
})
export class SetupTableHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
